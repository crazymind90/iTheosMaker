#import <Preferences/PSListController.h>

@interface BundleControllerRootListController : PSListController

@end
